package com.broodrooster.windesheimapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
